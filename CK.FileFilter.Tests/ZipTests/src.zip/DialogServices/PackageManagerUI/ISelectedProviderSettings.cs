﻿
namespace NuGet.Dialog.PackageManagerUI {
    public interface ISelectedProviderSettings {
        int SelectedProvider { get; set; }
    }
}